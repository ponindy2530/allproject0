export class ItemObj {
    code: string;
    name: string;
    qty: number;
    price1: number;
    icd9code: string;
}
