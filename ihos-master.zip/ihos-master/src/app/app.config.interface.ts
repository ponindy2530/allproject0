export interface IAppConfig {
    serverIP: string;
    apiEndpoint: string;
    reportApi: string;
}
